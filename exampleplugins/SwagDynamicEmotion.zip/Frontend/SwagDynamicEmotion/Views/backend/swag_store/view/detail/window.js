
Ext.define('Shopware.apps.SwagStore.view.detail.Window', {
    extend: 'Shopware.window.Detail',
    alias: 'widget.swag-store-detail-window',

    title : '{s name=title}Store details{/s}',
    height: 420,
    width: 900
});
