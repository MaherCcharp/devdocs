<?php

namespace SwagEvents\Components;

interface NameClassInterface
{
    /**
     * @return string
     */
    public function getName();
}