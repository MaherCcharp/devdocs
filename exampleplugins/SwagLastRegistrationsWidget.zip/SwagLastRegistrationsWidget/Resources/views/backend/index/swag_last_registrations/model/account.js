

Ext.define('Shopware.apps.Index.swagLastRegistrationsWidget.model.Account', {

    extend: 'Shopware.data.Model',

    fields: [
        'id',
        'customer',
        'customergroup',
        'date'
    ]
});